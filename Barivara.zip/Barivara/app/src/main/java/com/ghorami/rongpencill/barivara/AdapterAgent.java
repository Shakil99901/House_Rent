package com.ghorami.rongpencill.barivara;

import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.support.v7.widget.RecyclerView;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;


public class AdapterAgent extends RecyclerView.Adapter<AdapterAgent.ViewHolder> {
    private ArrayList<AndroidVersion> android;
    private Context context;
    public LinearLayout placeHolder;
    public LinearLayout placeNameHolder;
    public TextView placeName;
    public ImageView placeImage;
    String adserial2, category, usid, ItemPos, sopnoi, uname, uimage;
    String agentName, agentId, agentPic;



    public AdapterAgent(Context context, ArrayList<AndroidVersion> android) {
        this.android = android;
        this.context = context;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.agentlayout, viewGroup, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final ViewHolder viewHolder, int i) {
       // final Place place = new PlaceData().placeList().get(position);
        Typeface custom_font = Typeface.createFromAsset(context.getAssets(),  "fonts/NotoSansBengali.ttf");


        if(android.get(i).getName().equals ("")){
            viewHolder.tvName.setVisibility(View.GONE);
        }else if (android.get(i).getName() .equals ("Negotiation"))
            viewHolder.tvName.setText(Html.fromHtml(android.get(i).getName()));

        else {
            viewHolder.tvName.setText(Html.fromHtml( android.get(i).getName()));
        }

        viewHolder.tvSid.setText(android.get(i).getSopnoid());

        if(android.get(i).getImage().equals ("")){
            viewHolder.img_android.setImageResource(R.drawable.ic_launcher);

        } else {
            viewHolder.tvImg.setText(Html.fromHtml(android.get(i).getImage()));
            Picasso.with(context).load(android.get(i).getImage()).transform(new CircleTransform()).into(viewHolder.img_android);

        }

        agentId = android.get(i).getSopnoid();
        agentName = android.get(i).getName();
        agentPic = android.get(i).getImage();




    }


    @Override
    public int getItemCount() {

        return android.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
        private TextView tvName, tvSid, tvImg;
      ImageView img_android;
        public ViewHolder(View view) {
            super(view);

            tvImg = (TextView)view.findViewById(R.id.tvImg);
            tvName = (TextView)view.findViewById(R.id.tvName);

            tvSid = (TextView)view.findViewById(R.id.tvSid);
            if(tvSid !=null){
                tvSid.setVisibility(View.GONE);
            } else {
                tvSid.setVisibility(View.GONE);
                Toast toast = Toast.makeText(context, "Sorry No Data Found",
                        Toast.LENGTH_LONG);
                toast.show();
            }

            img_android = (ImageView)view.findViewById(R.id.ivbachelor);
            if(img_android !=null){
                img_android.setVisibility(View.VISIBLE);
            } else {
                img_android.setVisibility(View.GONE);
            }



            view.setOnClickListener(this);



        }


        @Override
        public void onClick(View v) {
            agentId = tvSid.getText().toString();
            agentPic = tvImg.getText().toString();
            agentName = tvName.getText().toString();

            Intent intent = new Intent(v.getContext(), DetailsChat.class);
            intent.putExtra("imageAgent", agentPic);
            intent.putExtra("agentN", agentName);
            intent.putExtra("agentID", agentId);
            // etc.
            Toast.makeText(v.getContext(), agentId, Toast.LENGTH_LONG).show();
            v.getContext().startActivity(intent);

        }
    }

}